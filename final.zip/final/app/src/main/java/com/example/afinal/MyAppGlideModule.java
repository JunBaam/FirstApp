package com.example.afinal;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

/**
 * Created by js on 2018-06-09.
 */

@GlideModule
public final class MyAppGlideModule extends AppGlideModule {}
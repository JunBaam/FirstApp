package com.example.afinal;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ChartActivity extends AppCompatActivity {


    //원형차트에대한정보 (책 카테고리 19개)
    PieChart pieChart;
    private ArrayList<String> categoryList;

    private  ArrayList<String>  소설=new ArrayList<>();
    private  ArrayList<String>  시에세이=new ArrayList<>();
    private  ArrayList<String>  경제경영=new ArrayList<>();
    private  ArrayList<String>  자기계발=new ArrayList<>();
    private  ArrayList<String>  인문=new ArrayList<>();
    private  ArrayList<String>  역사문화=new ArrayList<>();
    private  ArrayList<String>  종교 =new ArrayList<>();
    private  ArrayList<String> 정치사회=new ArrayList<>();
    private  ArrayList<String> 예술대중문화=new ArrayList<>();
    private  ArrayList<String> 과학=new ArrayList<>();
    private  ArrayList<String> 컴퓨터=new ArrayList<>();
    private  ArrayList<String> 외국어=new ArrayList<>();
    private  ArrayList<String> 가정육아=new ArrayList<>();
    private  ArrayList<String> 건강=new ArrayList<>();
    private  ArrayList<String>  여행=new ArrayList<>();
    private  ArrayList<String> 요리=new ArrayList<>();
    private  ArrayList<String> 취미실용스포츠=new ArrayList<>();
    private  ArrayList<String> 잡지=new ArrayList<>();
    private  ArrayList<String> 만화=new ArrayList<>();

//막대그래프에 대한정보

    BarChart barChart;
    ArrayList<BarChart> barChartArrayList;
    ArrayList<String> labelsName;

    private  ArrayList<String>  January  =new ArrayList<>();
    private  ArrayList<String>  Febuary =new ArrayList<>();
    private  ArrayList<String>  March  =new ArrayList<>();
    private  ArrayList<String>  April =new ArrayList<>();
    private  ArrayList<String>  May =new ArrayList<>();
    private  ArrayList<String>  June =new ArrayList<>();
    private  ArrayList<String>   July  =new ArrayList<>();
    private  ArrayList<String>  Auquest =new ArrayList<>();
    private  ArrayList<String>  September =new ArrayList<>();
    private  ArrayList<String>  Octover =new ArrayList<>();
    private  ArrayList<String>  November =new ArrayList<>();
    private  ArrayList<String>  December =new ArrayList<>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chart);

        ActionBar actionbar = getSupportActionBar();
        actionbar.hide();



       //다읽은 월에 대한 정보를 가져올 쉐어드
        SharedPreferences date =getSharedPreferences("다읽은책",MODE_PRIVATE);
        String getdate = date.getString("BookFinish",null);

        ArrayList<String> MonthList =new ArrayList<>();
        try {
            JSONObject dateObject = new JSONObject(getdate);
            JSONArray dateArray =dateObject.getJSONArray("BookFinish");
            for(int i = 0 ; i<dateArray.length(); i++) {
                JSONObject finishDate = dateArray.getJSONObject(i);

                String Month =  finishDate.getString("bookend");//다읽은책날짜

                System.out.println("다읽은전체날짜"+Month);//HomeActivity에 저장된 갯수만큼 날짜출력

                 Month.substring(5,8); //월부분만 잘라서 가져옴 (ex10월)
          //      String category =  bookdata.getString("bookcategory");

                System.out.println("다읽은전체월"+ Month.substring(5,8));
                if(Month.substring(5,8).contains("01월") == true ) {
                    January.add( Month.substring(5,8));
                }
                if(Month.substring(5,8).contains("02월") == true ) {
                    Febuary.add( Month.substring(5,8));
                }
                if(Month.substring(5,8).contains("03월") == true ) {
                    March.add( Month.substring(5,8));
                }
                if(Month.substring(5,8).contains("04월") == true ) {
                    April.add( Month.substring(5,8));
                }
                if(Month.substring(5,8).contains("05월") == true ) {
                   May.add("소설");
                }
                if(Month.substring(5,8).contains("06월") == true ) {
                   June.add( Month.substring(5,8));
                }
                if(Month.substring(5,8).contains("07월") == true ) {
                    July.add( Month.substring(5,8));
                }
                if(Month.substring(5,8).contains("08월") == true ) {
                    Auquest.add(Month.substring(5,8));
                }
                if(Month.substring(5,8).contains("09월") == true ) {
                   September.add(Month.substring(5,8));
                }
                if(Month.substring(5,8).contains("10월") == true ) {
                    Octover.add(Month.substring(5,8));
                }
                if(Month.substring(5,8).contains("11월") == true ) {
                    November.add(Month.substring(5,8));
                }
                if(Month.substring(5,8).contains("12월") == true ) {
                    December.add(Month.substring(5,8));
                }

            }

        } catch (JSONException e) {
            e.printStackTrace();
        }







        //막대차트
        barChart = (BarChart)findViewById(R.id.barChart);

        //하단 라벨이름 설정
        Description barDescription =new Description();
        barDescription.setText("월별 읽은책의 갯수");
        barDescription.setTextSize(10f);

        barChart.setDescription(barDescription);

        //막대바
        BarDataSet barDataSet = new BarDataSet(getData(), "");
        barDataSet.setBarBorderWidth(2.0f);
        barDataSet.setColors(ColorTemplate.COLORFUL_COLORS); //막대의 색갈
        BarData barData = new BarData(barDataSet);



        //x축에 대한설정

        XAxis xAxis = barChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.TOP); //x축의 위치

        String[] months = new String[]{"1월","2월","3월","4월","5월",
                "6월","7월","8월","9월","10월","11월","12월"};

        IndexAxisValueFormatter formatter = new IndexAxisValueFormatter(months);

        xAxis.setLabelCount(months.length);   //x축 라벨의 갯수  설정안할시 6개만 나옴
        xAxis.setValueFormatter(formatter);   //x축에 적용


        barChart.setData(barData);
        barChart.setFitBars(true);     //막대 테두리설정 유무
        barChart.animateXY(1500, 1500);//차트애니메이션
        barChart.invalidate();








     /*
      1.
      "다읽은책" 쉐어드로부터 bookcategory(책분류) 에 대한 정보만 가져오고
      bookcategory에 해당정보가 있다면 카테고리 Arraylist에 값을추가한다.

      2.
      카테고리 Arraylist가 0이  아니면 원형차트에 들어갈 Arraylist, (ArrayList<PieEntry>) yValues에
      카테고리Arraylist의 갯수만큼 값을 추가한다.
      */

        SharedPreferences getdata =getSharedPreferences("다읽은책",MODE_PRIVATE);
        String get = getdata.getString("BookFinish",null);

        try {
            JSONObject jsonObject = new JSONObject(get);
            JSONArray jsonArray =jsonObject.getJSONArray("BookFinish");

            System.out.println("piechart"+jsonArray);

            int list_cnt = jsonArray.length(); //Json 배열 내 JSON 데이터 개수를 가져옴

            categoryList =new ArrayList<>();
            for(int i = 0 ; i<jsonArray.length(); i++) {
                JSONObject bookdata = jsonArray.getJSONObject(i);

                //category 에는 내가 현재선택한 category가 들어있음.
                String category =  bookdata.getString("bookcategory");
                System.out.println("현재선택한 카테고리"+ category);
                if(category.contains("소설") == true ) {
                    소설.add("소설");
                }
                if(category.contains("시/에세이") == true ) {
                    시에세이.add("시/에세이");
                }
                if(category.contains("경제/경영") == true ) {
                   경제경영.add("경제/경영");
                }
                if(category.contains("자기계발") == true ) {
                    자기계발.add("자기계발");
                }
                if(category.contains("인문") == true ) {
                    인문.add("인문");
                }
                if(category.contains("종교") == true ){
                    종교.add("종교");
                }
                if(category.contains("정치사회") == true ) {
                    정치사회.add("정치사회");
                }
                if(category.contains("예술/대중문화") == true ){
                    예술대중문화.add("예술/대중문화");
                }
                if(category.contains("과학") == true ) {
                    과학.add("과학");
                }
                if(category.contains("컴퓨터/IT") == true ) {
                    컴퓨터.add("컴퓨터/IT");
                }
                if(category.contains("외국어") == true ) {
                    외국어.add("외국어");
                }
                if(category.contains("가정/육아") == true ) {
                    가정육아.add("가정/육아");
                }
                if(category.contains("건강") == true ) {
                    건강.add("건강");
                }
                if(category.contains("여행") == true ) {
                    여행.add("여행");
                }
                if(category.contains("요리") == true ) {
                    요리.add("요리");
                }
                if(category.contains("취미/실용/스포츠") == true ) {
                    취미실용스포츠.add("취미/실용/스포츠");
                }
                if(category.contains("잡지") == true ) {
                    잡지.add("잡지");
                }
                if(category.contains("만화") == true ) {
                    만화.add("만화");
                }

                categoryList.add(category);
                System.out.println("내가원하는 category"+category);
            }
            System.out.println("리스트안에 갯수 "+  categoryList.size());

        } catch (JSONException e) {
            e.printStackTrace();
        }


        //원형그래프
        pieChart = (PieChart)findViewById(R.id.piechart);

        //원형 차트에 대한정보
        pieChart.setUsePercentValues(true);   //퍼센트표시 표시유무
        pieChart.getDescription().setEnabled(false);
        pieChart.setExtraOffsets(5,10,5,5);
        pieChart.setDragDecelerationFrictionCoef(0.95f);
        pieChart.setDrawHoleEnabled(true);  //가운데원 표시 유무
        pieChart.setHoleRadius(35f);         //가운데원의 크기
        pieChart.setTransparentCircleAlpha(0); //가운데원 원의형태
        pieChart.setCenterText("BookCategory!"); //가운데원 텍스트
        pieChart.setCenterTextSize(10);          //가운데원 텍스트 크기
        pieChart.setTransparentCircleRadius(61f);

        ArrayList<PieEntry> yValues = new ArrayList<PieEntry>();

        /* 앞에 값은 지분율 ,라벨명
          만약 list안에 값이 0이아니면 값을추가하게한다.  */

        if (소설.size() != 0) {
            yValues.add(new PieEntry(소설.size(), "소설"));
        }
        if (시에세이.size() != 0) {
            yValues.add(new PieEntry(시에세이.size(), "시/에세이"));
        }
        if (경제경영.size() != 0) {
            yValues.add(new PieEntry(경제경영.size(), "경제/경영"));
        }
        if (자기계발.size() != 0) {
            yValues.add(new PieEntry(자기계발.size(), "자기계발"));
        }
        if (인문.size() != 0) {
            yValues.add(new PieEntry(인문.size(), "인문"));
        }
        if (역사문화.size() != 0) {
            yValues.add(new PieEntry(역사문화.size(), "역사/문화"));
        }
        if (종교.size() != 0) {
            yValues.add(new PieEntry(종교.size(), "종교"));
        }
        if (정치사회.size() != 0) {
            yValues.add(new PieEntry(정치사회.size(), "정치/사회"));
        }
        if (예술대중문화.size() != 0) {
            yValues.add(new PieEntry(예술대중문화.size(), "예술대중문화"));
        }
        if (과학.size() != 0) {
            yValues.add(new PieEntry(과학.size(), "과학"));
        }
         if (컴퓨터.size() != 0) {
             yValues.add(new PieEntry(컴퓨터.size(), "컴퓨터/IT"));
         }
        if (외국어.size() != 0) {
            yValues.add(new PieEntry(외국어.size(), "외국어"));
        }
        if (가정육아.size() != 0) {
            yValues.add(new PieEntry(가정육아.size(), "가정/육아"));
        }
        if (건강.size() != 0) {
            yValues.add(new PieEntry(건강.size(), "건강"));
        }
        if (여행.size() != 0) {
            yValues.add(new PieEntry(여행.size(), "여행"));
        }
        if (요리.size() != 0) {
            yValues.add(new PieEntry(요리.size(), "요리"));
        }
        if (취미실용스포츠.size() != 0) {
            yValues.add(new PieEntry(취미실용스포츠.size(),"취미/실용/스포츠"));
        }
        if (잡지.size() != 0) {
            yValues.add(new PieEntry(잡지.size(), "잡지"));
        }
        if (만화.size() != 0) {
            yValues.add(new PieEntry(만화.size(), "만화"));
        }

         //중간 라벨
        Description description = new Description();
        description.setText("책카테고리 갯수");
        description.setTextSize(15);
        pieChart.setDescription(description);
        pieChart.animateY(1500, Easing.EasingOption.EaseInOutCubic); //애니메이션

        //맨 하단 라벨
        PieDataSet dataSet = new PieDataSet(yValues,"");
        dataSet.setSliceSpace(3f);
        dataSet.setSelectionShift(10f);
        dataSet.setColors(ColorTemplate.COLORFUL_COLORS);

        //저장된 카테고리 갯수에대한 정보
        PieData data = new PieData((dataSet));
        data.setValueTextSize(10f);
        data.setValueTextColor(Color.YELLOW); //퍼센트(지분율) 색갈

        pieChart.setData(data);



} //onCreate

    //막대그래프에 넣을 값을 설정한다.x축 , y축
    //각 월 List읠 갯수만큼 추가한다.
    private ArrayList getData() {
        ArrayList<BarEntry> entries = new ArrayList<>();
        entries.add(new BarEntry(0f, January.size()));
        entries.add(new BarEntry(1f, Febuary.size()));
        entries.add(new BarEntry(2f, March.size()));
        entries.add(new BarEntry(3f, April.size()));
        entries.add(new BarEntry(4f, May.size()));
        entries.add(new BarEntry(5f, June.size()));
        entries.add(new BarEntry(6f, July.size()));
        entries.add(new BarEntry(7f, Auquest.size()));
        entries.add(new BarEntry(8f, September.size()));
        entries.add(new BarEntry(9f, Octover.size()));
        entries.add(new BarEntry(10f, November.size()));
        entries.add(new BarEntry(11f, December.size()));
        return entries;
    }

}

package com.example.afinal;

public class MemoData {

    private String title;

    public MemoData(String title) {

        this.title = title;

    }

    public MemoData() {

    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

}
